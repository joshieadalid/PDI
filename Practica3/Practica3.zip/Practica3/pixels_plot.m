function colors = pixels_plot(n, v)
colors = v;
    figure(n)
    hold on
    grid on

    for i = 1:length(v)
        plot3(v(i, 1), v(i, 2), v(i, 3), '.', 'Color', round(v(i, :) / 255))
    end

    % Agregar etiquetas y título
    xlabel('R')
    ylabel('G')
    zlabel('B')
    hold off

end
