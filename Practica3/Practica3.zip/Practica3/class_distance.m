function [representative, distance] = class_distance(pixel, classes)
    representative = [];
    distance = 442;

    for i = 1:length(classes)
        
        calc_distance = sqrt( (pixel(1) - classes(i, 1)).^2 + (pixel(2) - classes(i, 2) ).^2 + ( pixel(3) - classes(i, 1)).^2 );
        disp(calc_distance)
        if calc_distance < distance
            distance = calc_distance;
            representative = classes(i,:);
        end

    end

end
