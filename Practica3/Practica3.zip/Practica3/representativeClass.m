function representative = representativeClass(pixel_samples, sections)
    %class = zeros(length(sections),3);
    representative = [];
    from = 1;

    for i = 1:length(sections)
        to = from - 1 + sections(i);
        representative(end + 1, :) = mean(pixel_samples(from:to, :),1);
        from = to + 1;
    end

end
