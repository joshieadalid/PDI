clc
clear all
close all
warning off all

img = imread("peppers.png");
m = [173, 12, 22;
     166, 7, 26;
     244, 96, 11;
     109, 91, 0;
     221, 72, 0;
     172, 162, 34;
     141, 131, 7;
     243, 97, 18;
     199, 23, 32;
     255, 255, 255;
     251, 251, 249;
     72, 38, 70;
     61, 31, 61];
m = impixel(img)
sorted_pixels = sortrows(m, 1);
%disp(msort)
r_diff = [0; diff(sorted_pixels(:, 1))];
g_diff = [0; diff(sorted_pixels(:, 2))];
b_diff = [0; diff(sorted_pixels(:, 3))];
%disp([msort(:,1), g_diff, b_diff]);

%disp(classLimits(r_diff));
disp(classLimits(g_diff));
%disp(classLimits(b_diff));
rep_classes = representativeClass(sorted_pixels, classLimits(g_diff));
disp(rep_classes)

disp('Ingrese un pixel para clasificar: ')
figure(2)
p = impixel(img)
most_representative = class_distance(p, rep_classes)
pixels_plot(10, rep_classes);