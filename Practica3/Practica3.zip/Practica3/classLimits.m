function limit = classLimits(col)
    limit = [];
    contador = 1;

    for i = 1:length(col) - 1
        if col(i + 1) < 0
            limit (end + 1) = contador;
            contador = 1;
        else
            contador = contador + 1;
        end
    end

    limit(end + 1) = contador;
end
